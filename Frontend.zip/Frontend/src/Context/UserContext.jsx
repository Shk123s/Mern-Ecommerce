import React, {  createContext, useState } from 'react'
import { useCookies } from 'react-cookie';
import { Navigate } from 'react-router-dom';
import { Link, useNavigate   } from 'react-router-dom'

 export  const Usercontext = createContext();
 
 export const UserProvider = ({children}) => {
    const [logoutData,setLogoutData]= useState(null);
//     const Navigate = useNavigate();
//      const [cookies,setcookie,removiecookie] = useCookies([]);  
//    const Logout = ()=>{
//     console.log("logutttttt");
//     removiecookie("jwt");
//     Navigate('/register');
   
//   } 
    // const value= {Logout}
  return (

    <Usercontext.Provider value={{logoutData,setLogoutData}}>
  {children}
    </Usercontext.Provider>
  )
}

